# ASU
facebook hacking toolkit
<br>
FULL TUTORIAL: https://youtu.be/qZn2rRaHAio
<br><br>
<img src="https://github.com/LOoLzeC/ASU/blob/master/raw/Screenshot_2019-02-25-04-31-13.png"/>
